import { logout } from "../service/userService";

const Logout = () => logout();

export default Logout;
